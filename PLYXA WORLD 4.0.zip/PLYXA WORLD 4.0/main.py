from colorama import init, Fore, Style
import requests
import time
import random
from fake_useragent import UserAgent
from datetime import datetime
import platform
import socket
import datetime
from termcolor import colored
import platform
import os
import sys
from pystyle import Colorate, Colors, Center
import os, json, random, string, ctypes, sys, pytz
from pystyle import Write, Colors, Colorate, Anime, System
from colorama import Fore, Style, init
from tls_client import Session
from datetime import datetime, timezone
from selenium import webdriver
os.system("pip install pystyle phonenumbers requests whois python-whois py-whois pywhois pythonwhois colorama")
import socket
import pystyle
import phonenumbers, phonenumbers.timezone, phonenumbers.carrier, phonenumbers.geocoder
import requests
import whois
import random
import colorama
import threading
import string
import faker
import bs4
import urllib.parse
import colorama
import concurrent.futures
import csv
if platform.system() == "Windows":
    import ctypes

    import os
    import time
    import requests, random, datetime, sys, time, argparse, os, colorama
    from colorama import Fore, Back, Style
    from colorama import init

    ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 3)
    enter = pystyle.Colorate.Horizontal(pystyle.Colors.green_to_black, (""))
    pystyle.Anime.Fade(
        pystyle.Center.Center('''  
        
██╗  ██╗███████╗██╗     ██╗      ██████╗ ██╗
██║  ██║██╔════╝██║     ██║     ██╔═══██╗██║
███████║█████╗  ██║     ██║     ██║   ██║██║
██╔══██║██╔══╝  ██║     ██║     ██║   ██║╚═╝
██║  ██║███████╗███████╗███████╗╚██████╔╝██╗
╚═╝  ╚═╝╚══════╝╚══════╝╚══════╝ ╚═════╝ ╚═╝
                         Нажмите Enter что бы продолжить!'''), pystyle.Colors.purple_to_red,
        pystyle.Colorate.Vertical, enter=True)


def Main():
    if platform.system() == "Windows":
        os.system("cls")
        pystyle.Write.Print(pystyle.Center.XCenter('''\n
         
                                                                      ▄███████▄  ▄█       ▄██   ▄   ▀████    ▐████▀    ▄████████       ▄█     █▄   ▄██████▄     ▄████████  ▄█       ████████▄  
                                                                     ███    ███ ███       ███   ██▄   ███▌   ████▀    ███    ███      ███     ███ ███    ███   ███    ███ ███       ███   ▀███ 
                                                                     ███    ███ ███       ███▄▄▄███    ███  ▐███      ███    ███      ███     ███ ███    ███   ███    ███ ███       ███    ███ 
                                                                     ███    ███ ███       ▀▀▀▀▀▀███    ▀███▄███▀      ███    ███      ███     ███ ███    ███  ▄███▄▄▄▄██▀ ███       ███    ███ 
                                                                   ▀█████████▀  ███       ▄██   ███    ████▀██▄     ▀███████████      ███     ███ ███    ███ ▀▀███▀▀▀▀▀   ███       ███    ███ 
                                                                     ███        ███       ███   ███   ▐███  ▀███      ███    ███      ███     ███ ███    ███ ▀███████████ ███       ███    ███ 
                                                                     ███        ███▌    ▄ ███   ███  ▄███     ███▄    ███    ███      ███ ▄█▄ ███ ███    ███   ███    ███ ███▌    ▄ ███   ▄███ 
                                                                    ▄████▀      █████▄▄██  ▀█████▀  ████       ███▄   ███    █▀        ▀███▀███▀   ▀██████▀    ███    ███ █████▄▄██ ████████▀  
                                                                                ▀                                                                              ███    ███ 
                                                                                                                   ,--,                  
                                                                                                                 ,--.'|       ,----..    
                                                                                                              ,--,  | :      /   /   \   
                                                                                                           ,---.'|  : '     /   .     :  
                                                                                                           ;   : |  | ;    .   /   ;.  \ 
                                                                                                           |   | : _' |   .   ;   /  ` ; 
                                                                                                           :   : |.'  |   ;   |  ; \ ; | 
                                                                                                           |   ' '  ; :   |   :  | ; | ' 
                                                                                                           \   \  .'. |   .   |  ' ' ' : 
                                                                                                            `---`:  | '   '   ;  \; /  | 
                                                                                                                 '  ; | ___\   \  ',  /  
                                                                                                                 |  : ;/  .\;   :    /   
                                                                                                                 '  ,/ \  ; |\   \ .'    
                                                                                                                 '--'   `--"  `---`        
                                       ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
                                       ┃ Сode: Python | Сoded: Plyxa | Tool: Plyxa\Плакса\Плюкса\Плюха 4.0 |TG: t.me/PlyxaWorld | Support: @PlyxaCode | Вступить в клан: @plyxacode , discord: plyxacoder      ┃                             
                                       ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛          
  \n'''), pystyle.Colors.orange, interval=0.000)
    pystyle.Write.Print(pystyle.Center.XCenter('''\n
                                                       ┌───────────────────────────────────────────────────────────────────────────────────────────────┐           
                                                       ┃       Search                  ┃      Discord Tools     ┃     Other                            ┃
                                                       ┃  [1] Поиск по БД              ┃  [4] Check Token(s)    ┃  [7] sms bomber                      ┃                                                 
                                                       ┃  [2] Поиск OSINT NICK         ┃  [5] GoDm              ┃  [8] Bomber TG  (use vpn)            ┃
                                                       ┃  [3] Поиск по номеру          ┃  [6] Raider            ┃  [9] Bomber TG 2.0 (use vpn)         ┃                         
                                                       ┃━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┃                      
                                                       ┃             [exit] Выйти      ┃    By Plyxa & #plx     ┃       [thx] Спасибо!                 ┃                  
                                                       └───────────────────────────────────────────────────────────────────────────────────────────────┘     '''), pystyle.Colors.orange, interval=0.000)

Main()


while True:
    select = pystyle.Write.Input("\n\n[?] Выберите пункт меню: ", pystyle.Colors.yellow, interval=0.001)


    if select == "3":
        phone = pystyle.Write.Input("\n[?] Введите номер телефона -> ", pystyle.Colors.orange, interval=0.001)


        def phoneinfo(phone):
            try:
                parsed_phone = phonenumbers.parse(phone, None)
                if not phonenumbers.is_valid_number(parsed_phone):
                    return pystyle.Write.Print(f"\n[!] Произошла ошибка -> Недействительный номер телефона\n",
                                               pystyle.Colors.green, interval=0.005)
                carrier_info = phonenumbers.carrier.name_for_number(parsed_phone, "en")
                country = phonenumbers.geocoder.description_for_number(parsed_phone, "en")
                region = phonenumbers.geocoder.description_for_number(parsed_phone, "ru")
                formatted_number = phonenumbers.format_number(parsed_phone,
                                                              phonenumbers.PhoneNumberFormat.INTERNATIONAL)
                is_valid = phonenumbers.is_valid_number(parsed_phone)
                is_possible = phonenumbers.is_possible_number(parsed_phone)
                timezona = phonenumbers.timezone.time_zones_for_number(parsed_phone)
                print_phone_info = f"""\n[+] Номер телефона -> {formatted_number}
[+] Страна -> {country}
[+] Регион -> {region}
[+] Оператор -> {carrier_info}
[+] Активен -> {is_possible}
[+] Валид -> {is_valid}
[+] Таймзона -> {timezona}
[+] Telegram -> https://t.me/{phone}
[+] Whatsapp -> https://wa.me/{phone}
[+] Viber -> https://viber.click/{phone}\n"""
                pystyle.Write.Print(print_phone_info, pystyle.Colors.green, interval=0.005)
            except Exception as e:
                pystyle.Write.Print(f"\n[!] Произошла ошибка -> {str(e)}\n", pystyle.Colors.orange, interval=0.005)


        phoneinfo(phone)



    if select == "2":
        nick = pystyle.Write.Input(f"\n[?] Введите никнейм -> ", pystyle.Colors.orange, interval=0.005)
        urls = [
            f"https://www.instagram.com/{nick}",
            f"https://www.tiktok.com/@{nick}",
            f"https://twitter.com/{nick}",
            f"https://www.facebook.com/{nick}",
            f"https://www.youtube.com/@{nick}",
            f"https://t.me/{nick}",
            f"https://www.roblox.com/user.aspx?username={nick}",
            f"https://www.twitch.tv/{nick}",
        ]
        for url in urls:
            try:
                response = requests.get(url)
                if response.status_code == 200:
                    pystyle.Write.Print(f"\n{url} - аккаунт найден", pystyle.Colors.orange, interval=0.005)
                elif response.status_code == 404:
                    pystyle.Write.Print(f"\n{url} - аккаунт не найден", pystyle.Colors.orange, interval=0.005)
                else:
                    pystyle.Write.Print(f"\n{url} - ошибка {response.status_code}", pystyle.Colors.orange,
                                        interval=0.005)
            except:
                pystyle.Write.Print(f"\n{url} - ошибка при проверке", pystyle.Colors.orange, interval=0.005)
        print()


    if select == '1':
        sys.path.insert(0, 'src')
        from search import search_phone_number_in_folder
        database_folder = 'Database'
        database_files = [os.path.join(database_folder, filename) for filename in os.listdir(database_folder)]
        for database_file in database_files:
            search_phone_number_in_folder(database_file)
        input("Нажмите Enter, чтобы продолжить!")


    elif select == '4':

        import json
        import os
        import time
        import requests
        import colorama
        from colorama import Fore, Back

        colorama.init(autoreset=True)
        # Constants
        VALID_TOKENS = []
        INVALID_TOKENS = []
        AUTOREG_TOKENS = []
        TOKEN_LIST = []
        TOKEN_LEN = 0
        COUNT = 0  # Counter for token checking progress
        HIDE_OUTPUT = True

        # File paths
        VALID_FILE_PATH = "valid.txt"
        INVALID_FILE_PATH = "invalid.txt"
        AUTOREG_FILE_PATH = "autoreg.txt"


        # Hide output
        def hide_chars(string):
            if not HIDE_OUTPUT:
                return string
            new_string = ""
            for char in string:
                if char.isalpha():
                    new_string += '#'
                else:
                    new_string += char
            return new_string


        def check_token(token):
            global COUNT

            print(
                f"{Fore.LIGHTYELLOW_EX}Проверяю{Fore.LIGHTMAGENTA_EX}:{Fore.BLACK + Back.WHITE}...{hide_chars(token[32:])}")

            headers = {
                "Authorization": token,
                "Content-Type": "application/json",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.9013 Chrome/108.0.5359.215 Electron/22.3.2 Safari/537.36"}

            chats = requests.get("https://discord.com/api/v8/users/@me/channels", headers=headers, timeout=7)

            if chats.status_code == 429:
                # Handle rate limit
                ratelimit = json.loads(chats.content)
                time.sleep(float(ratelimit["retry_after"] / 1000))
            elif chats.status_code in [401, 404, 403]:
                # Invalid token
                COUNT += 1
                INVALID_TOKENS.append(token.strip())
                print(f"{Fore.RED}НЕВАЛИД")
                print(f"{Fore.YELLOW}Проверено {Fore.CYAN}{COUNT}/{Fore.LIGHTCYAN_EX}{TOKEN_LEN}")
                return

            chats_count = len(json.loads(chats.text))
            if chats_count >= 10:
                # Valid token with more than 10 chats
                COUNT += 1
                VALID_TOKENS.append(token.strip())
                print(f"{Fore.GREEN}ВАЛИД (чатов больше 10)")
                print(f"{Fore.YELLOW}Проверено {Fore.CYAN}{COUNT}/{Fore.LIGHTCYAN_EX}{TOKEN_LEN}")
                return

            # Token has less than 10 chats, checking friends
            print(f"{Fore.WHITE}Истории чатов < 10 {Fore.YELLOW}Проверяю друзей{Fore.LIGHTYELLOW_EX}...")

            friends = requests.get("https://discord.com/api/v8/users/@me/relationships", headers=headers, timeout=5)
            friends_count = len(json.loads(friends.text))
            if friends_count >= 10:
                # Valid token with more than 10 friends
                COUNT += 1
                VALID_TOKENS.append(token.strip())
                print(f"{Fore.GREEN}ВАЛИД ( друзей больше 10)")
                print(f"{Fore.YELLOW}Проверено {Fore.CYAN}{COUNT}/{Fore.LIGHTCYAN_EX}{TOKEN_LEN}")
                return

            # Valid token with less than 10 friends and chats
            COUNT += 1
            AUTOREG_TOKENS.append(token.strip())
            print(f"{Fore.GREEN}ВАЛИД{Fore.WHITE} {Fore.RED}АВТОРЕГ")
            print(f"{Fore.YELLOW}Проверено {Fore.CYAN}{COUNT}/{Fore.LIGHTCYAN_EX}{TOKEN_LEN}")


        art = """\
        Токен чекер by PLYXA
        """

        # Main code
        if __name__ == "__main__":

            # ascii art with colorama and text "Deyzze"
            print(art)

            is_not_valid_path = True
            while is_not_valid_path:
                token_path = input(f"{Fore.GREEN}Название файла с токенами: ")
                if os.path.exists(token_path):
                    is_not_valid_path = False
                else:
                    print(f"""{Fore.RED}Файл не найден""")
                    is_not_valid_path = True

            TOKEN_LIST = []
            tokenlist = open(token_path).read().splitlines()
            for token in tokenlist:
                TOKEN_LIST.append(token.strip())

            TOKEN_LEN = len(TOKEN_LIST)

            for token in TOKEN_LIST:
                check_token(token)

            # Write valid tokens to valid.txt
            with open(VALID_FILE_PATH, "a") as valid_file:
                for token in VALID_TOKENS:
                    valid_file.write(token + "\n")

            # Write invalid tokens to invalid.txt
            with open(INVALID_FILE_PATH, "a") as invalid_file:
                for token in INVALID_TOKENS:
                    invalid_file.write(token + "\n")

            # Write autoreg tokens to autoreg.txt
            with open(AUTOREG_FILE_PATH, "a") as autoreg_file:
                for token in AUTOREG_TOKENS:
                    autoreg_file.write(token + "\n")

            print("\n" * 5)
            print(f"{Fore.CYAN}Token check completed.")
            print(
                f"{Fore.GREEN}Valid tokens ({len(VALID_TOKENS)}): {'HIDDEN' if HIDE_OUTPUT or len(VALID_TOKENS) > 20 else VALID_TOKENS}")
            print(
                f"{Fore.RED}Invalid tokens ({len(INVALID_TOKENS)}): {'HIDDEN' if HIDE_OUTPUT or len(INVALID_TOKENS) > 20 else INVALID_TOKENS}")
            print(
                f"{Fore.YELLOW}Autoreg tokens ({len(AUTOREG_TOKENS)}): {'HIDDEN' if HIDE_OUTPUT or len(AUTOREG_TOKENS) > 20 else AUTOREG_TOKENS}")



    elif select == '8':
        sys.path.insert(0, 'src')
        print("Open  Bomber(TG)...")
        from smstg import time

        time()

    elif select == '9':
        sys.path.insert(0, 'src')
        print("Open  Bomber(TG)2.O ...")
        from smstg2 import time

        time()

    elif select == '7':
        sys.path.insert(0, 'src')
        print("Open sms bomber")
        from bomber import time


    elif select == '5':

        # Указываем путь к исполняемому файлу
        exe_path = r'"src\GoDm\source.exe"'

        # Запускаем файл
        try:
            # Команда для запуска программы
            result = os.system(exe_path)
            if result == 0:
                print("Файл успешно запущен")
            else:
                print(f"Ошибка при запуске файла. Код возврата: {result}")
        except Exception as e:
            print(f"Произошла ошибка: {e}")


    if select == '6':
        pystyle.Write.Print('''\nRaider

        ЗА ПОКУПКОЙ TG PLYXACODE | DISCORD PLYXACODER\n''', pystyle.Colors.yellow, interval=0.005)




    if select == "exit":
        sure = pystyle.Write.Input("Вы действительно хотите выйти? Y/N")
        if sure.lower() == "y" or sure.lower() == "yes" or sure.lower() == "н" or sure.lower() == "нуы" or sure.lower() == "да" or sure.lower() == "lf":
            exit()
        else:
            continue
    pystyle.Write.Input("\n[?] Нажмите Enter для продолжения", pystyle.Colors.orange, interval=0.005)
    Main()

